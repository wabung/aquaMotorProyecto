package aquaMotor.aquaMotorProyecto;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.fxml.Initializable;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class NewClientController implements Initializable {

    // Controlador del AppBar
    @FXML
    private AppBarController appBarController;

    // Campos del formulario
    @FXML
    private TextField txtName;

    @FXML
    private TextField txtEmail;

    @FXML
    private TextField txtPhone;

    // Botones
    @FXML
    private Button btnSave;

    @FXML
    private Button btnClear;

    // Controladores de las tarjetas de usuario
    @FXML
    private UserCardController userCard1Controller;

    @FXML
    private UserCardController userCard2Controller;

    @FXML
    private UserCardController userCard3Controller;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Configurar el título del AppBar
        configurarAppBar();
        
        // Configurar las tarjetas de usuario con datos de ejemplo
        configurarUserCards();
    }

    private void configurarAppBar() {
        if (appBarController != null) {
            appBarController.setTitle("CUSTOMER SIGN UP");
            appBarController.setOnBackAction(this::volverAHome);
        }
    }

    private void configurarUserCards() {
        // Datos de ejemplo para las tarjetas de usuario
        if (userCard1Controller != null) {
            userCard1Controller.setUserData("NAME", "EMAIL", "NUMBER");
        }
        if (userCard2Controller != null) {
            userCard2Controller.setUserData("NAME", "EMAIL", "NUMBER");
        }
        if (userCard3Controller != null) {
            userCard3Controller.setUserData("NAME", "EMAIL", "NUMBER");
        }
    }

    @FXML
    private void handleSave() {
        String name = txtName.getText();
        String email = txtEmail.getText();
        String phone = txtPhone.getText();

        if (name.isEmpty() || email.isEmpty() || phone.isEmpty()) {
            System.out.println("Por favor, complete todos los campos");
            return;
        }

        System.out.println("Cliente guardado:");
        System.out.println("Nombre: " + name);
        System.out.println("Email: " + email);
        System.out.println("Teléfono: " + phone);

        // Actualizar la primera tarjeta de usuario con los nuevos datos
        if (userCard1Controller != null) {
            userCard1Controller.setUserData(name, email, phone);
        }

        // TODO: Aquí se debería guardar en una base de datos o lista
    }

    @FXML
    private void handleClear() {
        txtName.clear();
        txtEmail.clear();
        txtPhone.clear();
        System.out.println("Formulario limpiado");
    }

    private void volverAHome() {
        try {
            App.setRoot("sales/views/homeSales");
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Error al volver a la pantalla principal");
        }
    }

    // Métodos públicos para acceder a los datos del formulario
    public String getName() {
        return txtName.getText();
    }

    public String getEmail() {
        return txtEmail.getText();
    }

    public String getPhone() {
        return txtPhone.getText();
    }
}
