package aquaMotor.aquaMotorProyecto;

import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.fxml.Initializable;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class ShowInventoryController implements Initializable {

    // Controlador del AppBar
    @FXML
    private AppBarController appBarController;

    // Filtro de tipo
    @FXML
    private ComboBox<String> filterCombo;

    // Campo de búsqueda
    @FXML
    private TextField searchField;

    // Controladores de las tarjetas de vehículos (3x3 = 9 tarjetas)
    @FXML
    private VehicleCardController vehicleCard1Controller;

    @FXML
    private VehicleCardController vehicleCard2Controller;

    @FXML
    private VehicleCardController vehicleCard3Controller;

    @FXML
    private VehicleCardController vehicleCard4Controller;

    @FXML
    private VehicleCardController vehicleCard5Controller;

    @FXML
    private VehicleCardController vehicleCard6Controller;

    @FXML
    private VehicleCardController vehicleCard7Controller;

    @FXML
    private VehicleCardController vehicleCard8Controller;

    @FXML
    private VehicleCardController vehicleCard9Controller;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Configurar el título del AppBar
        configurarAppBar();

        // Configurar el ComboBox de filtros
        configurarFiltros();

        // Configurar el campo de búsqueda
        configurarBusqueda();

        // Cargar datos de ejemplo en las tarjetas de vehículos
        cargarVehiculosEjemplo();
    }

    private void configurarAppBar() {
        if (appBarController != null) {
            appBarController.setTitle("SHOW INVENTORY");
            appBarController.setOnBackAction(this::volverAHome);
        }
    }

    private void configurarFiltros() {
        if (filterCombo != null) {
            // Agregar opciones al ComboBox
            filterCombo.getItems().addAll(
                "All Types",
                "Sedan",
                "SUV",
                "Truck",
                "Coupe",
                "Van"
            );
            
            // Configurar listener para filtrar cuando cambie la selección
            filterCombo.setOnAction(event -> filtrarPorTipo());
        }
    }

    private void configurarBusqueda() {
        if (searchField != null) {
            // Configurar listener para búsqueda en tiempo real
            searchField.textProperty().addListener((observable, oldValue, newValue) -> {
                buscarVehiculo(newValue);
            });
        }
    }

    private void cargarVehiculosEjemplo() {
        // Cargar datos de ejemplo para cada tarjeta de vehículo
        if (vehicleCard1Controller != null) {
            vehicleCard1Controller.setVehicleData("TYPE", "MODEL", "COLOR", "YEAR", 
                "LICENSE", "NEED REPAIR", "PRICE");
        }
        if (vehicleCard2Controller != null) {
            vehicleCard2Controller.setVehicleData("TYPE", "MODEL", "COLOR", "YEAR", 
                "LICENSE", "NEED REPAIR", "PRICE");
        }
        if (vehicleCard3Controller != null) {
            vehicleCard3Controller.setVehicleData("TYPE", "MODEL", "COLOR", "YEAR", 
                "LICENSE", "NEED REPAIR", "PRICE");
        }
        if (vehicleCard4Controller != null) {
            vehicleCard4Controller.setVehicleData("TYPE", "MODEL", "COLOR", "YEAR", 
                "LICENSE", "NEED REPAIR", "PRICE");
        }
        if (vehicleCard5Controller != null) {
            vehicleCard5Controller.setVehicleData("TYPE", "MODEL", "COLOR", "YEAR", 
                "LICENSE", "NEED REPAIR", "PRICE");
        }
        if (vehicleCard6Controller != null) {
            vehicleCard6Controller.setVehicleData("TYPE", "MODEL", "COLOR", "YEAR", 
                "LICENSE", "NEED REPAIR", "PRICE");
        }
        if (vehicleCard7Controller != null) {
            vehicleCard7Controller.setVehicleData("TYPE", "MODEL", "COLOR", "YEAR", 
                "LICENSE", "NEED REPAIR", "PRICE");
        }
        if (vehicleCard8Controller != null) {
            vehicleCard8Controller.setVehicleData("TYPE", "MODEL", "COLOR", "YEAR", 
                "LICENSE", "NEED REPAIR", "PRICE");
        }
        if (vehicleCard9Controller != null) {
            vehicleCard9Controller.setVehicleData("TYPE", "MODEL", "COLOR", "YEAR", 
                "LICENSE", "NEED REPAIR", "PRICE");
        }
    }

    private void filtrarPorTipo() {
        String tipoSeleccionado = filterCombo.getValue();
        System.out.println("Filtrando por tipo: " + tipoSeleccionado);
        // TODO: Implementar lógica de filtrado real
    }

    private void buscarVehiculo(String texto) {
        if (texto != null && !texto.isEmpty()) {
            System.out.println("Buscando: " + texto);
            // TODO: Implementar lógica de búsqueda real
        }
    }

    private void volverAHome() {
        try {
            App.setRoot("sales/views/homeSales");
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Error al volver a la pantalla principal");
        }
    }

    // Métodos públicos para actualizar vehículos dinámicamente
    public void actualizarVehiculo(int index, String type, String model, String color, 
                                   String year, String license, String needRepair, String price) {
        VehicleCardController controller = getVehicleController(index);
        if (controller != null) {
            controller.setVehicleData(type, model, color, year, license, needRepair, price);
        }
    }

    private VehicleCardController getVehicleController(int index) {
        switch (index) {
            case 1:
                return vehicleCard1Controller;
            case 2:
                return vehicleCard2Controller;
            case 3:
                return vehicleCard3Controller;
            case 4:
                return vehicleCard4Controller;
            case 5:
                return vehicleCard5Controller;
            case 6:
                return vehicleCard6Controller;
            case 7:
                return vehicleCard7Controller;
            case 8:
                return vehicleCard8Controller;
            case 9:
                return vehicleCard9Controller;
            default:
                return null;
        }
    }
}
